import 'package:flutter/material.dart';
import 'package:elec/man.dart';

void main(){
  runApp(
    new MaterialApp(
      home :man(),
      debugShowCheckedModeBanner: false,
    )
  );
}