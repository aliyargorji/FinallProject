import 'package:elec/info.dart';
import 'package:flutter/material.dart';
import 'package:elec/power.dart';
import 'package:elec/equations.dart';
import 'package:elec/drag.dart';


class item extends StatefulWidget {
  @override
  _itemState createState() => _itemState();
}


class _itemState extends State<item> {

  var item_list = 
  [
      {
      'item_name' : 'item',
      'item_pic' : 'images/power.png',
      'item_exp' : 'Power Calculation',
      'class': new power()
      },

      {
      'item_name' : 'e1',
      'item_pic' : 'images/equa.png',
      'item_exp' : '3 variables Solution',
      'class': new equations()
      },

      {
      'item_name' : 'item',
      'item_pic' : 'images/e2.png',
      'item_exp' : 'Drag & Drop Items',
      'class': new MyApp()
      },

      {
      'item_name' : 'e3',
      'item_pic' : 'images/Developer.png',
      'item_exp' : 'About Developers',
      'class': new Info()
      },
];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
    itemCount: item_list.length,
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
    itemBuilder: (BuildContext context,int man){
     return Parsa(
       item_name: item_list[man]['item_name'],
       item_pic: item_list[man]['item_pic'],
       item_class :item_list[man]['class'],
       item_exp : item_list[man]['item_exp']
     );

    }
     
    //  child: GridView(
      
    //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
    //   padding: const EdgeInsets.all(3.0),
      
    //  children: <Widget>[

    //     Padding(padding: EdgeInsets.all(3.0)),
    //     Image.asset('images/power.png'),
    //     Image.asset('images/power.png'),
    //     Image.asset('images/power.png'),
        
    
    //  ],
    //   //   Image.asset('images/power.png'),
    //   //  Image.asset('images/power.png'),,
    //  ),
    );
  }
}
class Parsa extends StatelessWidget{

  final item_name;
  final item_pic;
  final item_class;
  final item_exp;

  Parsa({
   this.item_name,
   this.item_pic,
   this.item_class,
   this.item_exp
  });

  @override
Widget build(BuildContext context) {

      

      return Card(
      child: Hero(
        tag: Text('myHero'),
        child: Material(
          child: InkWell(
            onTap: ()=> Navigator.of(context).push(
         new MaterialPageRoute(
           builder: (context) => item_class
        ),
        
      ),
      child: GridTile(
           footer: new Container(
                  color: Colors.white30,
                  child: ListTile(
                    leading: new Text(item_exp),
                    // title: new Row(
                    //   children: <Widget>[
                    //     Expanded(
                    //       child: new Text(item_exp),
                    //     )
                    //   ],
                    // ),
                  ),
                ), 
          child: 
          
          new Container(
            
            child:
            
          Image.asset(item_pic,fit: BoxFit.cover),
          
          )
      ),
      ),
    
      ),
      
      ),
      
      );
      
}
}