import 'package:flutter/material.dart';
import 'package:elec/item.dart';


class equations extends StatefulWidget {
  @override
  _equationsState createState() => _equationsState();
}

class _equationsState extends State<equations> {

  TextEditingController txtx_res = new TextEditingController();
  TextEditingController txty_res = new TextEditingController();
  TextEditingController txtz_res = new TextEditingController();


  TextEditingController txt1_x = new TextEditingController();
  TextEditingController txt1_y = new TextEditingController();
  TextEditingController txt1_z = new TextEditingController();
  TextEditingController txt1_num = new TextEditingController();

  TextEditingController txt2_x = new TextEditingController();
  TextEditingController txt2_y = new TextEditingController();
  TextEditingController txt2_z = new TextEditingController();
  TextEditingController txt2_num = new TextEditingController();
  
 TextEditingController txt3_x = new TextEditingController();
  TextEditingController txt3_y = new TextEditingController();
  TextEditingController txt3_z = new TextEditingController();
  TextEditingController txt3_num = new TextEditingController();

    @override
   
  Widget build(BuildContext context) {
    

    double determinantOfMatrix(mat) 
  { 
    double ans; 
    ans = mat[0][0] * (mat[2][1] * mat[1][2] - mat[1][1] * mat[2][2]) 
      - mat[0][1] * (mat[2][0] * mat[1][2] - mat[2][2] * mat[1][0]) 
      + mat[0][2] * (mat[2][0] * mat[1][1] - mat[2][1] * mat[1][0]); 
    return ans; 
  } 
    

 // This function finds the solution of system of 
// linear equations using cramer's rule 
void findSolution(coeff) 
{ 
	// Matrix d using coeff as given in cramer's rule 
	var d = [ 
		[ coeff[0][0], coeff[0][1], coeff[0][2] ], 
		[ coeff[2][0], coeff[2][1], coeff[2][2] ], 
    [ coeff[1][0], coeff[1][1], coeff[1][2] ], 
  ]; 
	
	// Matrix d1 using coeff as given in cramer's rule 
var d1 = [ 
		[ coeff[0][3], coeff[0][1], coeff[0][2] ], 
		[ coeff[2][3], coeff[2][1], coeff[2][2] ], 
		[ coeff[1][3], coeff[1][1], coeff[1][2] ], 
    ]; 
	
	// Matrix d2 using coeff as given in cramer's rule 
	var d2 = [ 
		[ coeff[0][0], coeff[0][3], coeff[0][2] ], 
		[ coeff[2][0], coeff[2][3], coeff[2][2] ], 
		[ coeff[1][0], coeff[1][3], coeff[1][2] ], 
  ]; 
	
	// Matrix d3 using coeff as given in cramer's rule 
var d3 = [ 
		[ coeff[0][0], coeff[0][1], coeff[0][3] ], 
		[ coeff[2][0], coeff[2][1], coeff[2][3] ], 
  	[ coeff[1][0], coeff[1][1], coeff[1][3] ], 
    ]; 


// Calculating Determinant of Matrices d, d1, d2, d3 
	double D = determinantOfMatrix(d); 
	double D1 = determinantOfMatrix(d1); 
	double D2 = determinantOfMatrix(d2); 
	double D3 = determinantOfMatrix(d3); 
	print("D is  : %.6f ${D} \n" ); 
	print("D1 is : %.6f ${D1}\n" ); 
  print("D2 is : %.6f ${D2}\n" ); 
  print("D3 is : %.6f ${D3}\n" ); 
	// Case 1 
	if (D != 0) 
	{ 
		// Coeff have a unique solution. Apply Cramer's Rule 
		double x = D1 / D; 
		double y = D2 / D; 
		double z = D3 / D; // calculating z using cramer's rule 
		print("Value of x is :  $x \n"); 
		print("Value of y is :  $y \n");             //  %.6f
    print("Value of z is :  $z \n"); 
    
      //   {(double.parse(x)}

    txtx_res.text = '${(x.toStringAsFixed(2))}';
    txty_res.text = '${(y.toStringAsFixed(2))}';
    txtz_res.text = '${(z.toStringAsFixed(2))}';
	} 
	
	// Case 2 
	else
	{ 
		if (D1 == 0 && D2 == 0 && D3 == 0) 
			print("Infinite solutions\n"); 
		else if (D1 != 0 || D2 != 0 || D3 != 0) 
			print("No solutions\n"); 
	} 
} 

    return Scaffold(
      
     appBar: AppBar(
        elevation: 0.0 ,
        backgroundColor: Colors.red,
        title: InkWell(
        child:Text('equations'),
        onTap: (){Navigator.pop(context);}
        ),
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.send,color: Colors.white),onPressed: (){}),
         // new IconButton(icon: Icon(Icons.shutter_speed,color:Colors.red),onPressed: (){},)
        ],
       
      ),
      body: 
      
      GridView(
        
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4), 
    children: <Widget>[
      TextField(
        controller: txt1_x,
        decoration: InputDecoration(
          
          labelText: 'x'
        ),
      ),
       TextField(
        controller: txt1_y,
        decoration: InputDecoration(
          
          labelText: 'y'
        ),
      ),
       TextField(
        controller: txt1_z,
        decoration: InputDecoration(
          
          labelText: 'z'
        ),
      ),
       TextField(
        controller: txt1_num,
        decoration: InputDecoration(
          
          labelText: 'number'
        ),
      ),

      //########################################################
     TextField(
        controller: txt3_x,
        decoration: InputDecoration(
          
          labelText: 'x'
        ),
      ),
       TextField(
        controller: txt3_y,
        decoration: InputDecoration(
          
          labelText: 'y'
        ),
      ),
       TextField(
        controller: txt3_z,
        decoration: InputDecoration(
          
          labelText: 'z'
        ),
      ),
       TextField(
        controller: txt3_num,
        decoration: InputDecoration(
          
          labelText: 'number'
        ),
      ),

      //#######################################################
     TextField(
        controller: txt2_x,
        decoration: InputDecoration(
          
          labelText: 'x'
        ),
      ),
       TextField(
        controller: txt2_y,
        decoration: InputDecoration(
          
          labelText: 'y'
        ),
      ),
       TextField(
        controller: txt2_z,
        decoration: InputDecoration(
          
          labelText: 'z'
        ),
      ),
       TextField(
        controller: txt2_num,
        decoration: InputDecoration(
          

          labelText: 'number'
        ),
      ),
      //#####################################################################

      TextField(
        controller: txtx_res,
        decoration: InputDecoration(
          
          labelText: 'X is :'
        ),
      ),
      TextField(
        controller: txty_res,
        decoration: InputDecoration(
          
          labelText: 'Y is :'
        ),
      ),
      TextField(
        controller: txtz_res,
        decoration: InputDecoration(
          
          labelText: 'Z is :'
        ),
      ),

      // ########################### BE HAPPY######################

       TextField(
       
        decoration: InputDecoration(
          
          labelText: 'Be Happy :-) :'
        ),
      ),
      

      //########################################################
     Padding(
                padding: const EdgeInsets.all(2.0),
                child: Builder(
                  builder: (context) {
                    return RaisedButton(
                      
                      color: Colors.indigoAccent,
                      child: Text('calculate'),
                      onPressed: (){
                         setState(() {
                          
                            var coeff = [
                          [double.parse(txt1_x.text), double.parse(txt1_y.text), double.parse(txt1_z.text), double.parse(txt1_num.text)],
                          [double.parse(txt2_x.text), double.parse(txt2_y.text), double.parse(txt2_z.text), double.parse(txt2_num.text)],
                          [double.parse(txt3_x.text), double.parse(txt3_y.text), double.parse(txt3_z.text), double.parse(txt3_num.text)]
                    ];

                           
                            // print (coeff[0]);
                            // print (coeff[1]);     // this is 3th
                            // print (coeff[2]);     // this is 2th

                     findSolution(coeff);
                           


                            //  final row = 3; 
                            //  final col = 4;                         //   3 rows
                            //   final grid = List<List<int>>.generate(
                            //       row, (i) => List<int>.generate(col, (j) => i * col + j));
                            //   print(grid);
     
                           
                         });
                       } , 

                    );     
                  },
      ),
      
    ),
    
     Padding(
                padding: const EdgeInsets.all(2.0),
                child: Builder(
                  builder: (context) {
                    return RaisedButton(
                      
                      color: Colors.pink,
                      child: Text('erase'),
                      onPressed: (){
                         setState(() {
                           txt1_x.text='';
                           txt1_y.text='';
                           txt1_z.text='';
                           txt1_num.text='';

                           txt2_x.text='';
                           txt2_y.text='';
                           txt2_z.text='';
                           txt2_num.text='';

                           txt3_x.text='';
                           txt3_y.text='';
                           txt3_z.text='';
                           txt3_num.text='';
                          
                                                  });
                       } , 
                    );     
                  },
      ),
      
    ),
    //Image.asset('images/nat3.png',fit :BoxFit.fill),
    ],
    
       ),
       

    );


 
  }


  
 

}


