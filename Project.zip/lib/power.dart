 import 'package:flutter/material.dart';
 import 'package:elec/item.dart';


class power extends StatefulWidget {
  @override
  
  _powerState createState() => _powerState();
}

class _powerState extends State<power> {
   
  TextEditingController txt1 = TextEditingController();
  TextEditingController txt2 = TextEditingController();
  TextEditingController txt3 = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        elevation: 0.0 ,
        backgroundColor: Colors.red,
        title: InkWell(
        child:Text('power calculation'),

        // it look like a stack when you pop a page it goes back
        onTap: (){Navigator.pop(context);}        //{Navigator.push(context,MaterialPageRoute(builder: (context) => new item()));}
        ),
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.send,color: Colors.red),onPressed: (){}),
         // new IconButton(icon: Icon(Icons.shutter_speed,color:Colors.red),onPressed: (){},)
        ],
   
      ),
      
        body:
    
       GridView(
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2), 
    children: <Widget>[
      TextField(
        controller: txt1,
        decoration: InputDecoration(
          
          labelText: 'R'
        ),
      ),
      TextField(
         controller: txt2,
        textInputAction: TextInputAction.send,
        decoration: InputDecoration(
          labelText: 'I'
          
        ),
      ),
      TextField(
        
         controller: txt3,
        textInputAction: TextInputAction.send,
        decoration: InputDecoration(
          labelText: 'power is equal to:'
          
        ),
      ),

     Padding(
                padding: const EdgeInsets.all(40.0),
                child: Builder(
                  builder: (context) {
                    return RaisedButton(
                      
                      color: Colors.indigoAccent,
                      child: Text('calculate'),
                      onPressed: (){
                         setState(() {
                           try{
                           if (txt1.text.contains(RegExp('[a-z]')) || txt2.text.contains(RegExp('[a-z]')) )
                           txt3.text = 'wrong entry... Please try another';

                            if (txt1.text.contains(RegExp('[A-Z]')) || txt2.text.contains(RegExp('[A-Z]')) )
                            txt3.text = 'wrong entry... Please try another';

                           txt3.text = '${(double.parse(txt1.text)*double.parse(txt2.text)*double.parse(txt2.text)).toStringAsFixed(2)}';
                                                  }catch (exception,formatException){
                                                    print ('false input');
                                                  };
                         });
                       } , 

                    );     
                  },
      ),
      
    ),
    
     Padding(
                padding: const EdgeInsets.all(40.0),
                child: Builder(
                  builder: (context) {
                    return RaisedButton(
                      
                      color: Colors.pink,
                      child: Text('erase'),
                      onPressed: (){
                         setState(() {
                           txt1.text='';
                           txt2.text='';
                           txt3.text = '';
                                                  });
                       } , 
                    );     
                  },
      ),
      
    ),
    ],
       ),
    );
}
}




















































































// class power extends StatefulWidget {
//   @override
//   _powerState createState() => _powerState();
// }

// class _powerState extends State<power> {

//   TextEditingController nameController = TextEditingController();
//   TextEditingController locationController = TextEditingController();
//   TextEditingController descriptionController = TextEditingController();

//   @override
//   Widget build(BuildContext context) {

//     double num1;
//     double num2;

//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Add a new Dog'),
//         backgroundColor: Colors.black87,
//       ),
     
//       body:
     
//         Container(
        
//         //color: Colors.black54,
//         child: Padding(
//           padding: const EdgeInsets.symmetric(
//             vertical: 8.0,
//             horizontal: 32.0,
//           ),
//           child: Column(
//             children: [
              
//  //             Image.asset('images/ohm1.png'),
//               // Image(
              
//               // image: AssetImage('images/ohm1.png'),
//               // width: 533.0,
//               // height: 243.0,
//               // fit: BoxFit.fill,
//               //  ),
//               // Text("someText"),

//               Padding(
//                 padding: const EdgeInsets.only(bottom: 8.0),
//                 child: TextField(
//                     // Tell your textfield which controller it owns
//                     controller: nameController,
//                     // Every single time the text changes in a
//                     // TextField, this onChanged callback is called
//                     // and it passes in the value.
//                     //
//                     // Set the text of your controller to
//                     // to the next value.
//                     onChanged: (v) => nameController.text = v,
//                     decoration: InputDecoration(
//                       icon: Icon(Icons.kitchen),
//                       labelText: 'R',
//                     )),
//               ),
//               Padding(
//                 padding: const EdgeInsets.only(bottom: 8.0),
                
//                 child: TextField(
                    
//                     controller: locationController,
//                     onChanged: (v) => locationController.text = v,
//                     decoration: InputDecoration(
//                       icon: Icon(Icons.power),
//                       labelText: "I",
//                     ),
                   
//                     ),
                     
//               ),
             
//               //  Padding(  padding: const EdgeInsets.only(bottom: 8.0),
//               //   child: TextField(
//               //       controller: descriptionController,
//               //       onChanged: (v) => descriptionController.text = v,
                    
//               //       decoration: InputDecoration(
//               //         icon: Icon(Icons.keyboard),
//               //         labelText: 'All about the pup',
//               //       )),
//               // ),

//               new Padding(
//               padding: const EdgeInsets.only(top: 20.0),
//             ),
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Builder(
//                   builder: (context) {
//                     return MaterialButton(
//                       color: Colors.indigoAccent,
//                       child: Text('calculate'),
//                       onPressed: (){
//                           new Padding(
//                 padding: const EdgeInsets.all(30.0),
                      
          
//                           );
//                        } ,       
//                          //     setState((){'${double.parse(locationController.text)*double.parse(nameController.text)}';});              
//                            ); 
//                      // =>  print('PRESSED');
                     
                   
//                   },
//                 ),
//               ),
//             //    Padding(
//             //     padding: const EdgeInsets.all(16.0),
//             //     child:
//             //   new TextField(
//             //   keyboardType: TextInputType.number,
//             //   decoration: InputDecoration( hintText:'lkk'),
//             //   controller: nameController,
//             // ),

//               // Padding(
                
//               //   padding: const EdgeInsets.all(16.0),
//               //   child :
//               //   Text('${double.parse(locationController.text)*double.parse(nameController.text)}'),
               
               
//               // ),

//               // SizedBox(
//               //   width: 18,
//               //   child: Container(
//               //     child: Text('$res'),
//               //   ),

//               // ) 
//              //  )
//             ],
//           ),
//         ),
//       ),
    
//     );
//   }
  
  
// }