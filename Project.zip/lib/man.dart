import 'package:elec/info.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:elec/item.dart';


class man extends StatefulWidget {
  @override
  _manState createState() => _manState();
}

class _manState extends State<man> {
  @override
  Widget build(BuildContext context) {

     Widget image_carousel = new Container(
         height: 200,
         child: new Carousel(
         boxFit: BoxFit.cover,
         images : [
             AssetImage('images/e1.png'),
             AssetImage('images/e2.png'),
             AssetImage('images/e3.png'),
             AssetImage('images/e4.png'),
             AssetImage('images/e5.png')
           ],
           autoplay : true,
           dotSize : 3,
           dotBgColor : Colors.transparent,
           animationCurve : Curves.fastOutSlowIn,
           animationDuration : Duration(milliseconds: 1000)
           )
         );
       

      
    return Scaffold(
      appBar:  AppBar(
        elevation: 0.0,
        backgroundColor: Colors.red,
        title: (new Text('Electronic Circuits')),
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.search),color: Colors.white,onPressed: (){},),
          new IconButton(icon: Icon(Icons.email),color: Colors.white,onPressed: (){
            // Navigator.push(context, new MaterialPageRoute(builder: (context)=> new dumbass()));
          })

        ],

      ),

      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
             new UserAccountsDrawerHeader(
            accountName: Text('Eelectronic Circuits'),
            accountEmail: Text('sara.ershadinasab@gmail.com'),
            currentAccountPicture: GestureDetector(
              child: new CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(Icons.person,color :Colors.red),
              ),
            ),
            decoration: new BoxDecoration(
              color: Colors.cyan,
            ),
            ),
            

            //////////// ------------////////// body:

            InkWell(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Info()),
                );
              },
              child: ListTile(
                title : Text('About Us'),
                leading: Icon(Icons.home,color : Colors.red),
              )
            ),
/*
            InkWell(
              onTap: (){},
              child: ListTile(
                title : Text('HomePage'),
                leading: Icon(Icons.home,color : Colors.red),
              )
            ),

            InkWell(
              onTap: (){},
              child: ListTile(
                title : Text('HomePage'),
                leading: Icon(Icons.home,color : Colors.red),
              )
            ),

            InkWell(
              onTap: (){},
              child: ListTile(
                title : Text('HomePage'),
                leading: Icon(Icons.home,color : Colors.red),
              )
            ),

            InkWell(
              onTap: (){},
              child: ListTile(
                title : Text('HomePage'),
                leading: Icon(Icons.home,color : Colors.red),
              )
            ),
*/






          ],
        ),
      ),

    body: ListView(
      children: <Widget>[
        image_carousel,
      /*  new Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Elements'),
          ),

 //         horizon(),

        new Padding(
          padding: const EdgeInsets.all(20.0),
          child: new Text('Circuit'),
        ),
        */
        new Container(
         child: item(),
          height: 360.0,
        )
      ],
    ),

    );
     
      
    
  }
}